# Governance

1. **Incremental changes only.** Preserve validated sections and change only the required delta.
2. **Preview before production.** Every material web change is published to `/preview/` and reviewed in a real browser before root promotion.
3. **Immutable releases.** Approved candidates remain under `/docs/releases/<version>/` for rollback and traceability.
4. **No Norte Solar mixing.** No Norte Solar repository, secret, Drive location, AI OS memory or automation may become authoritative for this project.
5. **Explicit status.** Proposed allies, roles, legal pathways and institutional relationships remain clearly marked until confirmed.
6. **Validation gate.** Internal links, anchors, local assets, HTML parsing, responsive rendering and console errors must pass before promotion.
7. **Source integrity.** Research references and images retain attribution and source traceability.
