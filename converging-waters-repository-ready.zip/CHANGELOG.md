# Changelog

## v13-preview — 2026-08-04
- Preserved the complete v13 content.
- Extracted embedded images into deduplicated web assets.
- Optimized the 1448×1086 purpose-led measurement infographic at high WebP quality without resizing.
- Added width, height, lazy loading and asynchronous decoding to raster images.
- Added immutable release, preview and production-promotion structure.
- Added validation workflow and cross-project web-preview standard.
