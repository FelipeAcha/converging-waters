#!/usr/bin/env python3
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse
import sys

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
errors=[]

class Parser(HTMLParser):
    def __init__(self, path):
        super().__init__(); self.path=path; self.ids=set(); self.refs=[]; self.links=[]
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if 'id' in a:
            if a['id'] in self.ids: errors.append(f"{self.path}: duplicate id {a['id']}")
            self.ids.add(a['id'])
        if tag in ('img','script','source') and a.get('src'): self.refs.append(a['src'])
        if tag=='link' and a.get('href'): self.refs.append(a['href'])
        if tag=='a' and a.get('href'): self.links.append(a['href'])

for html in DOCS.rglob('*.html'):
    p=Parser(html)
    try: p.feed(html.read_text('utf-8'))
    except Exception as e: errors.append(f"{html}: parse error {e}"); continue
    for ref in p.refs:
        if ref.startswith(('http://','https://','data:','#','mailto:','tel:')): continue
        target=(html.parent/ref.split('?',1)[0].split('#',1)[0]).resolve()
        if not target.exists(): errors.append(f"{html}: missing asset {ref}")
    for href in p.links:
        if href.startswith('#') and href[1:] not in p.ids:
            errors.append(f"{html}: missing anchor {href}")
        elif not href.startswith(('http://','https://','mailto:','tel:','#','javascript:')):
            clean=href.split('?',1)[0].split('#',1)[0]
            target=(html.parent/clean).resolve()
            if clean and not target.exists(): errors.append(f"{html}: missing local link {href}")
        elif href.startswith(('http://','https://')):
            u=urlparse(href)
            if not u.netloc: errors.append(f"{html}: malformed external URL {href}")

if errors:
    print('\n'.join(errors)); sys.exit(1)
print('PASS: HTML, local assets, local links, anchors and URL syntax')
