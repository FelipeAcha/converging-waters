#!/usr/bin/env python3
from pathlib import Path
from html.parser import HTMLParser
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys

ROOT = Path(__file__).resolve().parents[1] / 'docs'
urls = set()

class Parser(HTMLParser):
    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            href = dict(attrs).get('href', '')
            if href.startswith(('http://', 'https://')):
                urls.add(href)

for file in ROOT.rglob('*.html'):
    parser = Parser()
    parser.feed(file.read_text('utf-8'))

def check(url):
    for method in ('HEAD', 'GET'):
        try:
            req = Request(url, method=method, headers={'User-Agent': 'Mozilla/5.0 ConvergingWatersLinkCheck/1.0'})
            with urlopen(req, timeout=12) as response:
                return url, response.status, None
        except HTTPError as exc:
            if exc.code in (401, 403, 405, 429):
                if method == 'HEAD' and exc.code == 405:
                    continue
                return url, exc.code, None
            if exc.code in (404, 410):
                return url, exc.code, 'broken'
        except (URLError, TimeoutError) as exc:
            last_error = str(exc)
    return url, None, last_error

broken = []
warnings = []
with ThreadPoolExecutor(max_workers=10) as pool:
    futures = [pool.submit(check, url) for url in sorted(urls)]
    for future in as_completed(futures):
        url, status, note = future.result()
        if note == 'broken':
            broken.append(f'{status} {url}')
        elif status is None:
            warnings.append(f'UNVERIFIED {url} ({note})')

if warnings:
    print('External links requiring browser-level verification:')
    print('\n'.join(sorted(warnings)))
if broken:
    print('Broken external links:')
    print('\n'.join(sorted(broken)))
    sys.exit(1)
print(f'PASS: no confirmed 404/410 among {len(urls)} external links')
