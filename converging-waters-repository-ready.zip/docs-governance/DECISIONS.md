# Decision log

## CW-DEC-2026-08-04-001 — Independent repository
**Decision:** Converging Waters will use a personal public repository under `FelipeAcha`, separate from Norte Solar.

## CW-DEC-2026-08-04-002 — Real preview URLs
**Decision:** Complete HTML websites will be reviewed through a public HTTP(S) preview URL, not a ChatGPT or Drive attachment.

## CW-DEC-2026-08-04-003 — Immutable release model
**Decision:** Each validated candidate is retained under `/docs/releases/<version>/`; `/preview/` points to the candidate and `/` is promoted separately.
