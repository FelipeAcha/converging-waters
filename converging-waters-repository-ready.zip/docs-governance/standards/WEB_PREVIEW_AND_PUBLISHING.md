# Web preview and publishing standard

## Problem

HTML attached through ChatGPT `sandbox:` links or Google Drive is treated as a file for code viewing or download, not as an executable website. Notebook-rendered HTML is also not a reliable full-site preview surface in chat.

## Required operating rule

1. Detect HTML/web deliverables before claiming an interactive preview exists.
2. Do not call an attachment link a preview.
3. Publish a review candidate to a real HTTP(S) preview URL.
4. Validate the public URL in desktop and mobile viewports.
5. Verify local assets, internal anchors, external URL syntax, console errors and horizontal overflow.
6. Promote to production only after explicit approval.
7. Preserve the reviewed candidate as an immutable release for rollback.

## Cross-project scope

This is a generic delivery standard applicable to personal projects and Norte Solar. Only the generic standard may be cross-registered; Converging Waters content and infrastructure remain outside Norte Solar.
